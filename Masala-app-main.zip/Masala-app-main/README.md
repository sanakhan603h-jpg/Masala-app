# Masala-app
Android app to create masala recipes for all the world regions
